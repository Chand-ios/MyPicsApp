//
//  SearchBarView.swift
//  MyPics
//
//  Created by eAlphaMac2 on 25/05/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit

class SearchBarView: UICollectionReusableView {
@IBOutlet weak var searchBar: UISearchBar!
@IBOutlet weak var micBtn: UIButton!

}
