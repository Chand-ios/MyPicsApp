//
//  AboutViewController.swift
//  MyPics
//
//  Created by eAlphaMac2 on 24/04/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit
import WebKit

class AboutViewController: UIViewController {

    @IBOutlet weak var webVieww: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
