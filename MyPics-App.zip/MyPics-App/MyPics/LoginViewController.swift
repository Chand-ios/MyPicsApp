//
//  LoginViewController.swift
//  FutureElite
//
//  Created by eAlpha4Tech on 31/01/20.
//  Copyright © 2020 eAlpha4Tech. All rights reserved.
//

import UIKit
import CRNotifications
import Firebase
@available(iOS 13.0, *)
class LoginViewController: UIViewController,UIScrollViewDelegate {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var passwordTxtFld: UITextField!
    @IBOutlet weak var forgotPasswordBtn: UIButton!
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var hideBtn: UIButton!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var rememberBtn: UIButton!

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var actInd = UIActivityIndicatorView()


    var scrollOffset : CGFloat = 0
    var distance : CGFloat = 0
    var activeField: UITextField?
    var lastOffset: CGPoint!
    var keyboardHeight: CGFloat!
    var ref: DatabaseReference!


    override func viewDidLoad() {
        super.viewDidLoad()
        // Activity Indicator
         actInd.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0);
         actInd.center = self.view.center
         actInd.hidesWhenStopped = true
         actInd.style = UIActivityIndicatorView.Style.gray
         self.view.addSubview(actInd)
        
        ref = Database.database().reference()

        let defaults: UserDefaults? = UserDefaults.standard
        if(defaults?.value(forKey: "EMAIL") != nil){
        emailTxtFld.text = defaults!.value(forKey: "EMAIL") as? String
        }
        emailTxtFld.delegate = self
        passwordTxtFld.delegate = self
        contentView.layer.shadowPath = UIBezierPath(rect: contentView.bounds).cgPath
        contentView.layer.shadowRadius = 15
        //#colorLiteral(red: 0.8542710543, green: 0.8544148803, blue: 0.8542521, alpha: 1)
        contentView.layer.shadowColor = #colorLiteral(red: 0.6746426225, green: 0.6747580767, blue: 0.6746274829, alpha: 1)
        self.contentView.layer.cornerRadius = 5
        contentView.layer.shadowOffset = .zero
        contentView.layer.shadowOpacity = 0.5
        signInBtn.backgroundColor = #colorLiteral(red: 0.1215686275, green: 0.3098039216, blue: 0.6196078431, alpha: 1)
        self.signInBtn.layer.cornerRadius = 20
        signInBtn.clipsToBounds = true
       // headerView.backgroundColor = .clear

        // Keyboard Appears view is scrolled.
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        
        self.hidekeyboard()
        setColoredLabel()
        hideBtn.setImage(UIImage(named: "hide"), for: .normal)
        hideBtn.setImage(UIImage(named: "unhide"), for: .selected)
       

    }
    @IBAction func rememberActiomn(_ sender: UIButton) {
             let defaults: UserDefaults? = UserDefaults.standard
          //(sender.isSelected)
             if sender.isSelected == true {
              sender.setBackgroundImage(#imageLiteral(resourceName: "checkbox"), for: .normal)
              defaults?.set(false, forKey: "ISRemember")
              sender.isSelected = false
             }
             else {
              defaults?.set(true, forKey: "ISRemember")
              sender.setBackgroundImage(#imageLiteral(resourceName: "check-box"), for: .normal)
              defaults?.set(emailTxtFld.text, forKey: "SavedUserName")
              defaults?.set(passwordTxtFld.text, forKey: "SavedPassword")
              sender.isSelected = true
               
                 }
         }
    @objc func adjustForKeyboard(notification: Notification) {
           guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
           
           let keyboardScreenEndFrame = keyboardValue.cgRectValue
           let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
           
           if notification.name == UIResponder.keyboardWillHideNotification {
               scrollView.contentInset = .zero
           } else {
               scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom, right: 0)
           }
           
       }
       
       func hidekeyboard(){
           let tap: UITapGestureRecognizer = UITapGestureRecognizer (target: self, action: #selector(Dissmisskeyboard))
           view.addGestureRecognizer(tap)

       }
       
       @objc func Dissmisskeyboard(){
           view.endEditing(true)
       }
func setColoredLabel() {
//           var string: NSMutableAttributedString = NSMutableAttributedString(string: "Don't have an account? Sign Up")
//           string.setColorForText(textToFind: "Don't have an account? ", withColor: UIColor.darkGray)
//           string.setColorForText(textToFind: "Sign Up", withColor: #colorLiteral(red: 0, green: 0.3150609732, blue: 0.6413818002, alpha: 1))
//         signInBtn.titleLabel!.attributedText = string
       }
       
   
    @IBAction func backAction(_ sender: UIButton) {
        if (self.navigationController != nil) {
        for vc in  self.navigationController!.viewControllers {
            if vc is ViewController {
                 self.navigationController?.popToViewController(vc, animated: false)
            }
        }
        }
        
    }
    @IBAction func forgotPasswordAction(_ sender: UIButton) {
        if(emailTxtFld.text == nil || emailTxtFld.text == ""){
                 CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter email", dismissDelay: 2)
              return
                }
            Auth.auth().sendPasswordReset(withEmail: emailTxtFld.text!) { (error) in
                      if error == nil{
                         CRNotifications.showNotification(type: CRNotifications.success, title: "Success", message: "We have just sent you a password reset mail. Please check inbox and follow the instructions to reset password", dismissDelay: 4)
                       print("We have just sent you a password reset mail. Please check inbox and follow the instructions to reset password")
                      }
                      
                  }
             
    }
   
    @IBAction func signupAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(identifier: "SignUpViewController") as! SignUpViewController
            self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func signinAction(_ sender: UIButton) {
        self.actInd.startAnimating()
        emailTxtFld.resignFirstResponder()
        passwordTxtFld.resignFirstResponder()
        if(emailTxtFld.text == nil || emailTxtFld.text == ""){
            self.actInd.stopAnimating()

           CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter email", dismissDelay: 2)
        return
          }
        if(passwordTxtFld.text == nil || passwordTxtFld.text == ""){
            self.actInd.stopAnimating()

          CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Password", dismissDelay: 2)
          return
          }
       // activityIndicator.startAnimating()
        Auth.auth().signIn(withEmail: emailTxtFld.text!, password: passwordTxtFld.text!) {(authResult, error) in
            
            if let error = error {
               // self.activityIndicator.stopAnimatingOnMainThread()

                if let errCode = AuthErrorCode(rawValue: error._code) {
                    switch errCode {
                    case .invalidEmail:
                        self.actInd.stopAnimating()

                        print("invalid mail")
                        CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "invalid mail", dismissDelay: 2)
                    case .wrongPassword:
                        self.actInd.stopAnimating()
                        print("wrongPassword")
                        CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Wrong Password", dismissDelay: 2)
                    default:
                    self.actInd.stopAnimating()
                        print("wrongPassword")

                        CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "\(error.localizedDescription)", dismissDelay: 2)
                    }
                }
                return
            }
        
            if let user = authResult?.user {
                let defaults: UserDefaults? = UserDefaults.standard
                let userss = user.uid
                print(authResult?.user ?? "0")
                user.getIDToken { (result, error) in
                    defaults?.set(result, forKey: "IDTOKEN")
                }

                defaults?.set(userss, forKey: "uid")
                let QuizRef = self.ref.child("Users")
                let query = QuizRef.queryOrdered(byChild: "user_id").queryEqual(toValue: "\(userss )")
                query.observeSingleEvent(of: .value, with: { snapshot in
                for child in snapshot.children {
                    let childSnap = child as! DataSnapshot
                    let dict = childSnap.value as! [String: Any]
                    print(dict)
                    self.actInd.stopAnimating()
                    let email = dict["user_email"] as? String ?? ""
                    let user_id  = dict["user_id"] as? String ?? ""
                    let mobileNumber  = dict["phone_number"] as? String ?? ""
                    let name  = dict["name"] as? String ?? ""
                    defaults?.set(email, forKey: "EMAIL")
                    defaults?.set(name, forKey: "NAME")
                    defaults?.set(mobileNumber, forKey: "MOBILE")
                    defaults?.set(user_id, forKey: "user_id")
                    UserDefaults.standard.set(true, forKey: "status")
                   let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                    
                    }
                })

            }
       else {

       }
        }
       
        
    }
  
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        emailTxtFld.resignFirstResponder()
        passwordTxtFld.resignFirstResponder()
        return true
    }
    
    @IBAction func hideAction(_ sender: Any) {
          if hideBtn.isSelected {
              hideBtn.isSelected = false
              passwordTxtFld.isSecureTextEntry = true
              if passwordTxtFld.isFirstResponder {
                  passwordTxtFld.resignFirstResponder()
                  passwordTxtFld.becomeFirstResponder()
              }
          } else {
              hideBtn.isSelected = true
              passwordTxtFld.isSecureTextEntry = false
              if passwordTxtFld.isFirstResponder {
                  passwordTxtFld.resignFirstResponder()
                  passwordTxtFld.becomeFirstResponder()
              }
          }
          
      }
}
@available(iOS 13.0, *)
extension LoginViewController: UITextFieldDelegate {
    // Remove error message after start editing
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
       // textField.setError()
        return true
    }

    // Check error
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //Validator.isValidEmail(field: textField)
    }

    // Check error
    func textFieldDidEndEditing(_ textField: UITextField) {
       // Validator.isValidEmail(field: textField, show: false)
    }
}

class Validator {
    static let EMAIL_ADDRESS =
        "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
        "\\@" +
        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
        "(" +
            "\\." +
            "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
        ")+"

    // Validator e-mail from string
    static func isValidEmail(_ value: String) -> Bool {
        let string = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let predicate = NSPredicate(format: "SELF MATCHES %@", Validator.EMAIL_ADDRESS)
        return predicate.evaluate(with: string) || string.isEmpty
    }

    static func isValidEmail(field: UITextField, show: Bool = true) -> Bool {
        if Validator.isValidEmail(field.text!) {
           // field.setError()
            return true
        } else {
           // field.setError("Error message", show: show)
        }
        return false
    }
}



