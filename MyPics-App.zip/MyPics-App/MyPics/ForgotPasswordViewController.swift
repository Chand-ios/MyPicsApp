//
//  ForgotPasswordViewController.swift
//  MyPics
//
//  Created by eAlphaMac2 on 13/05/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit
import Firebase

class ForgotPasswordViewController: UIViewController,UIScrollViewDelegate,UITextFieldDelegate {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var cnfrmPasswordTxtFle: UITextField!
    @IBOutlet weak var passwordTxtFld: UITextField!
    @IBOutlet weak var updateBtn: UIButton!
    var actInd = UIActivityIndicatorView()
    var email:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        cnfrmPasswordTxtFle.delegate = self
        passwordTxtFld.delegate = self
        contentView.layer.shadowPath = UIBezierPath(rect: contentView.bounds).cgPath
        contentView.layer.shadowRadius = 15
        //#colorLiteral(red: 0.8542710543, green: 0.8544148803, blue: 0.8542521, alpha: 1)
        contentView.layer.shadowColor = #colorLiteral(red: 0.6746426225, green: 0.6747580767, blue: 0.6746274829, alpha: 1)
        self.contentView.layer.cornerRadius = 5
        contentView.layer.shadowOffset = .zero
        contentView.layer.shadowOpacity = 0.5
        updateBtn.backgroundColor = #colorLiteral(red: 0.1215686275, green: 0.3098039216, blue: 0.6196078431, alpha: 1)
        self.updateBtn.layer.cornerRadius = 20
        // Do any additional setup after loading the view.
    }
    
    @IBAction func updateActionn(_ sender: Any) {
            self.actInd.startAnimating()
            passwordTxtFld.resignFirstResponder()
            cnfrmPasswordTxtFle.resignFirstResponder()
            guard passwordTxtFld.text != nil else {
               //CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter email", dismissDelay: 2)
            return
              }
            guard cnfrmPasswordTxtFle.text != nil else {
    //           CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Password", dismissDelay: 2)
              return
              }
      
    }
    

}
