//
//  ImageListViewController.swift
//  MyPics
//
//  Created by eAlphaMac2 on 21/04/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit
import SDWebImage
import Firebase
import FirebaseDatabase
@available(iOS 13.0, *)

class ImageListViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource
{
    @IBOutlet weak var headerLbl: UILabel!
    var ref: DatabaseReference!
    var listImages:[[String:Any]] = []
    var collectionImage = UIImageView()
    var albumNameLbl = UILabel()
    var headerStr = String()
    var deleteStr:String!
    var deleteBtn = UIButton()


    
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var trashBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        headerLbl.text = headerStr
        deleteStr = ""
        collection.delegate = self
        collection.dataSource = self
        // Do any additional setup after loading the view.
    }
    @IBAction func backAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
       }
    @IBAction func trashAction(_ sender: UIButton) {
        deleteStr = "delete"
        collection.reloadData()
    }
   func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        //cell.backgroundColor = .red
        cell.layer.cornerRadius = 4
        cell.clipsToBounds = true
        
        collectionImage = UIImageView.init(frame: CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height))
        print(listImages)
        let imageUrl = listImages[indexPath.item]["url"]
        //collectionImage.image = UIImage.init(named: imageArr[0])
        //let albumName = imageUrl[0]["url"]
        let fileUrl = URL(string: imageUrl as! String)
        print(fileUrl!)
        collectionImage.sd_setImage(with: fileUrl!, placeholderImage: UIImage(named: "photo-gallery"))
            
        cell.addSubview(collectionImage)
        deleteBtn = UIButton.init(frame: CGRect(x: cell.frame.width-30, y: 0, width: 30, height: 30))
               deleteBtn.backgroundColor = .black
              deleteBtn.alpha = 0.5
              deleteBtn.layer.cornerRadius = 4
              deleteBtn.clipsToBounds = true
              deleteBtn.setImage(UIImage(named: "more"), for: .normal)
              deleteBtn.addTarget(self, action: #selector(deletecellAction), for: .touchUpInside)
              deleteBtn.tag = indexPath.item
        if deleteStr == "" {
                    deleteBtn.isHidden = true

        }
        else{
            deleteBtn.isHidden = false

        }
               cell.addSubview(deleteBtn)
        
        return cell
    }
    @objc func deletecellAction(_ sender: UIButton)  {
        print("Button pressed 👍 ")

        let hitPoint = sender.convert(CGPoint.zero, to: self.collection)
        let hitIndex: IndexPath? = self.collection.indexPathForItem(at: hitPoint)
           let childName = String(sender.tag)
           
                     self.collection.performBatchUpdates({
                       self.remove(child: childName)
                       self.collection.deleteItems(at: [hitIndex!])
                       self.listImages.remove(at: sender.tag)
           }) { (finished) in
               self.collection.reloadItems(at: self.collection.indexPathsForVisibleItems)
           }
    }
    func remove(child: String) {
        let defaults: UserDefaults? = UserDefaults.standard

       let user_id = defaults!.value(forKey: "user_id") as? String

    let refff = self.ref.child("Myfiles/\(user_id!)/\(headerStr)")
        refff.child(child).removeValue { error, _ in

            print(error)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //let padding: CGFloat =  50
        let collectionViewSize = collectionView.frame.size.width
        let collectionViewSizes = collectionView.frame.size.height
        
        return CGSize(width: collectionViewSize/3-8, height: collectionViewSizes/5)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
        let vc = self.storyboard?.instantiateViewController(identifier: "PreviewViewController") as! PreviewViewController
        vc.imageArr = listImages
        let imageUrl = listImages[indexPath.item]["url"]
        vc.imgUrl = imageUrl as! String
        vc.index = Int(indexPath.item)
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
