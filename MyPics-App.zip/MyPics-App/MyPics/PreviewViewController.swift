//
//  PreviewViewController.swift
//  MyPics
//
//  Created by eAlphaMac2 on 09/05/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit

class PreviewViewController: UIViewController,UIScrollViewDelegate {
    var imageArr:[[String:Any]] = []
    var imgUrl = String()
    var index:Int!
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var pageControl: UIPageControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.scroll.frame = CGRect(x:0, y:76, width:self.view.frame.width, height:self.view.frame.height)
               let scrollViewWidth:CGFloat = self.scroll.frame.width
               let scrollViewHeight:CGFloat = self.scroll.frame.height
        for i in 0..<imageArr.count {

               let imageView = UIImageView()
            let fileUrl = URL(string: imageArr[i]["url"] as! String )
                   print(fileUrl!)
                   imageView.sd_setImage(with: fileUrl!, placeholderImage: UIImage(named: "1"))
               //imageView.image =
               let xPosition = UIScreen.main.bounds.width * CGFloat(i)
               imageView.frame = CGRect(x: xPosition, y: 0, width: scroll.frame.width, height: scroll.frame.height)
               imageView.contentMode = .scaleAspectFit
           self.scroll.contentSize = CGSize(width:self.scroll.frame.width * CGFloat(i+1), height:self.scroll.frame.height)
                  self.pageControl.currentPage = i

               //scroll.contentSize.width = scroll.frame.width * CGFloat(i + 1)
               scroll.addSubview(imageView)
              scroll.delegate = self



           }
       

//        let fileUrl = URL(string: imgUrl as! String)
//        print(fileUrl!)
//        img.sd_setImage(with: fileUrl!, placeholderImage: UIImage(named: "1"))
        scroll.minimumZoomScale = 1.0
        scroll.maximumZoomScale = 6.0
        self.scroll.delegate = self
    }
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {

        return scroll.superview
    }
    
    @IBAction func sharingAction(_ sender: Any) {
        print(self.pageControl.currentPage)
        let fileUrl = URL(string: imageArr[index]["url"] as! String )
                          print(fileUrl!)
         img.sd_setImage(with: fileUrl!, placeholderImage: UIImage(named: "1"))
                         
        let image = img.image
        let imageShare = [ image! ]
        let activityViewController = UIActivityViewController(activityItems: imageShare , applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view 
        self.present(activityViewController, animated: true, completion: nil)
    }
    
}

private typealias ScrollView = PreviewViewController
extension ScrollView
{
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView){
        // Test the offset and calculate the current page after scrolling ends
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        // Change the indicator
        print("counrttt",currentPage)
        self.pageControl.currentPage = Int(currentPage);
        index = Int(currentPage)
        // Change the text accordingly
       
        }
    }

