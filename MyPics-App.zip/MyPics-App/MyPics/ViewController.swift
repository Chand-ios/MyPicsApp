//
//  ViewController.swift
//  MyPics
//
//  Created by apple on 4/16/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit
import OpalImagePicker
import Photos
import FirebaseStorage
import SDWebImage
import Firebase
import FirebaseDatabase
import Intents
import Speech



@available(iOS 13.0, *)
class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource,OpalImagePickerControllerDelegate,UISearchBarDelegate,SFSpeechRecognizerDelegate {
//    let audioEngine = AVAudioEngine()
//       let speechRecognizer: SFSpeechRecognizer? = SFSpeechRecognizer()
//       let request = SFSpeechAudioBufferRecognitionRequest()
//       var recognitionTask: SFSpeechRecognitionTask?
//       var isRecording = false
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-US"))!
       
       private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
       private var recognitionTask: SFSpeechRecognitionTask?
       private let audioEngine = AVAudioEngine()
       
    
    
    
    var ref: DatabaseReference!
    var albumnames:[String] = []
    var albumimages:[[[String:Any]]] = []
    var defaults: UserDefaults? = UserDefaults.standard
    var user_id:String!
    var collectionImage = UIImageView()
    var albumNameLbl = UILabel()
    var deleteBtn = UIButton()

    var actInd = UIActivityIndicatorView()
    var filteredData: [String]!
    var filteredImagesData: [[[String:Any]]]!
    var searchText:String?
    @IBOutlet weak var voiceLbl: UILabel!
    @IBOutlet weak var voiceImage: UIImageView!
    @IBOutlet weak var blurBtn: UIButton!
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var addAlbumBtn: UIButton!
    @IBOutlet weak var headerLbl: UILabel!
    @IBOutlet weak var emptyView: UIView!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var micBtn: UIButton!

   
    //MARK: - Check Authorization Status
    func requestSpeechAuthorization() {
        speechRecognizer.delegate = self
               
      SFSpeechRecognizer.requestAuthorization { (authStatus) in
                   
                   var isButtonEnabled = false
                   
                   switch authStatus {
                   case .authorized:
                       isButtonEnabled = true
                       
                   case .denied:
                       isButtonEnabled = false
                       print("User denied access to speech recognition")
                       
                   case .restricted:
                       isButtonEnabled = false
                       print("Speech recognition restricted on this device")
                       
                   case .notDetermined:
                       isButtonEnabled = false
                       print("Speech recognition not yet authorized")
                   }
                   
                   OperationQueue.main.addOperation() {
                       self.micBtn.isEnabled = isButtonEnabled
                   }
               }
    }
    //MARK: - Alert
    func sendAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func micAction(_ sender: UIButton) {
       if audioEngine.isRunning {
//            audioEngine.stop()
//            recognitionRequest?.endAudio()
//            micBtn.isEnabled = false
//        self.blurBtn.isHidden = true
//        self.voiceLbl.isHidden = true
           // microphoneButton.setTitle("Start Recording", for: .normal)
        } else {
            startRecording()
        self.blurBtn.isHidden = false
        self.voiceLbl.isHidden = false
            //microphoneButton.setTitle("Stop Recording", for: .normal)
        }
       
    }
    @IBAction func blurAction(_ sender: UIButton) {
         if audioEngine.isRunning {
                    audioEngine.stop()
                    recognitionRequest?.endAudio()
                    micBtn.isEnabled = false
                self.blurBtn.isHidden = true
                self.voiceLbl.isHidden = true
                   // microphoneButton.setTitle("Start Recording", for: .normal)
                } else {
        }
    }
    func cancelRecording() {
        audioEngine.stop()
         if audioEngine.inputNode.numberOfInputs > 0 {
         audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionTask?.cancel()
    }
     @IBAction func refreshAction(_ sender: UIButton) {
        self.albumnames = self.filteredData
        self.albumimages = self.filteredImagesData
        self.collection.reloadData()

    }
    func startRecording() {
            
            if recognitionTask != nil {  //1
                recognitionTask?.cancel()
                recognitionTask = nil
            }
            
            let audioSession = AVAudioSession.sharedInstance()  //2
            do {
                try audioSession.setCategory(AVAudioSession.Category.record)
                try audioSession.setMode(AVAudioSession.Mode.measurement)
               // try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
            } catch {
                print("audioSession properties weren't set because of an error.")
            }
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()  //3
            let inputNode = audioEngine.inputNode
    //        guard let inputNode = audioEngine.inputNode else {
    //            fatalError("Audio engine has no input node")
    //        }  //4
            
            guard let recognitionRequest = recognitionRequest else {
                fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
            } //5
            
            recognitionRequest.shouldReportPartialResults = true  //6
            
            recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in  //7
                
                var isFinal = false  //8
                
                if result != nil {
                    
//                      self.blurBtn.isHidden = true
//                    self.voiceLbl.isHidden = true
                    isFinal = (result!.isFinal)
                                    self.searchText = result?.bestTranscription.formattedString
                                    self.albumnames.removeAll()
                                    self.albumimages.removeAll()
                                    print(self.filteredData!)
                                   for (index, item) in self.filteredData.enumerated() {
                                                             print(item.lowercased())
                                                          print(self.searchText!.lowercased())
                                                          if (item.lowercased().contains(self.searchText!.lowercased())) {
                                                                 self.albumnames.append(item)
                                                              self.albumimages.append(self.filteredImagesData[index])
                                                             }
                    
                    
                                    }
                                    if (self.searchText!.isEmpty) {
                                                             self.albumnames = self.filteredData
                                                      self.albumimages = self.filteredImagesData
                                                  }
                    if self.audioEngine.isRunning {
                        self.audioEngine.stop()
                        recognitionRequest.endAudio()
                        self.micBtn.isEnabled = false
                    self.blurBtn.isHidden = true
                    self.voiceLbl.isHidden = true
                       // microphoneButton.setTitle("Start Recording", for: .normal)
                    }
                    else{
                        
                    }
                                   self.collection.reloadData()  //9
                    isFinal = (result?.isFinal)!
                }
                
                if error != nil || isFinal {  //10
                    self.audioEngine.stop()
                    inputNode.removeTap(onBus: 0)
                    
                    self.recognitionRequest = nil
                    self.recognitionTask = nil
                    
                    self.micBtn.isEnabled = true
                }
            })
            
            let recordingFormat = inputNode.outputFormat(forBus: 0)  //11
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
                self.recognitionRequest?.append(buffer)
            }
            
            audioEngine.prepare()  //12
            
            do {
                try audioEngine.start()
            } catch {
                print("audioEngine couldn't start because of an error.")
            }
            
            //textView.text = "Say something, I'm listening!"
            
        }
        
        func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
            if available {
                micBtn.isEnabled = true
            } else {
                micBtn.isEnabled = false
            }
        }
//    func recordAndRecognizeSpeech() {
//        let node = audioEngine.inputNode
//        let recordingFormat = node.outputFormat(forBus: 0)
//        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
//            self.request.append(buffer)
//        }
//        audioEngine.prepare()
//        do {
//            try audioEngine.start()
//        } catch {
//            self.sendAlert(title: "Speech Recognizer Error", message: "There has been an audio engine error.")
//            return print(error)
//        }
//        guard let myRecognizer = SFSpeechRecognizer() else {
//            self.sendAlert(title: "Speech Recognizer Error", message: "Speech recognition is not supported for your current locale.")
//            return
//        }
//        if !myRecognizer.isAvailable {
//            self.sendAlert(title: "Speech Recognizer Error", message: "Speech recognition is not currently available. Check back at a later time.")
//            // Recognizer is not available right now
//            return
//        }
//        recognitionTask = speechRecognizer?.recognitionTask(with: request, resultHandler: { result, error in
//            if let result = result {
//                var isFinal = false  //8
//
//                let bestString = result.bestTranscription.formattedString
//                var lastString: String = ""
//                for segment in result.bestTranscription.segments {
//                    let indexTo = bestString.index(bestString.startIndex, offsetBy: segment.substringRange.location)
//                    lastString = String(bestString[indexTo...])
//                }
//                print(lastString)
//                self.blurBtn.isHidden = true
//                self.voiceLbl.isHidden = true
//                isFinal = (result.isFinal)
//                self.searchText = bestString
//                self.albumnames.removeAll()
//                self.albumimages.removeAll()
//                print(self.filteredData!)
//               for (index, item) in self.filteredData.enumerated() {
//                                         print(item.lowercased())
//                                      print(self.searchText!.lowercased())
//                                      if (item.lowercased().contains(self.searchText!.lowercased())) {
//                                             self.albumnames.append(item)
//                                          self.albumimages.append(self.filteredImagesData[index])
//                                         }
//
//
//                }
//                if (self.searchText!.isEmpty) {
//                                         self.albumnames = self.filteredData
//                                  self.albumimages = self.filteredImagesData
//                              }
//               self.collection.reloadData()
//                if error != nil || isFinal {
//                self.cancelRecording()
//                }
//                //self.checkForColorsSaid(resultString: lastString)
//            } else if let error = error {
//                self.sendAlert(title: "Alert", message: "There has been a speech recognition error.")
//                print(error)
//            }
//
//
//        })
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.blurBtn.isHidden = true
       self.voiceLbl.isHidden = true
       
//        voiceImage.image = jeremyGif
        self.requestSpeechAuthorization()
        self.view.bringSubviewToFront(micBtn)
        self.micBtn.layer.cornerRadius = micBtn.frame.size.width/2
        self.micBtn.clipsToBounds = true
        self.addAlbumBtn.layer.cornerRadius = 4
        self.addAlbumBtn.clipsToBounds = true
        self.emptyView.isHidden = true
        headerLbl.layer.shadowColor = UIColor.gray.cgColor
        headerLbl.layer.shadowRadius = 2.0
        headerLbl.layer.shadowOpacity = 1.0
        headerLbl.layer.shadowOffset = CGSize(width: 2, height: 2)
        headerLbl.layer.masksToBounds = false
        
        // Activity Indicator
        actInd.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0);
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.style = UIActivityIndicatorView.Style.gray
        self.view.addSubview(actInd)
        
        ref = Database.database().reference()
        user_id = defaults!.value(forKey: "user_id") as? String
        
        getMyFiles()
        collection.delegate = self
        collection.dataSource = self

    }
    
   
    func getMyFiles()
{
    
    
    print("namesssss",albumnames)
    self.actInd.startAnimating()
    let QuizRef = self.ref.child("Myfiles/\(user_id!)")
    // let query = QuizRef.queryOrdered(byChild: "user_id").queryEqual(toValue: "\(user_id! )")
    QuizRef.observe(.childRemoved, with: { snapshot in

   // QuizRef.observeSingleEvent(of: .value, with: { snapshot in
        self.albumnames.removeAll()
        self.albumimages.removeAll()
        if !snapshot.exists() {
            self.emptyView.isHidden = false

        }
        var albumimge:[String]=[]

    for child in snapshot.children {

    let childSnap = child as! DataSnapshot
    let dict = childSnap.value as! [[String:Any]]
    let albumName = childSnap.key
    //print(imageName)
    print(childSnap.key)
    self.albumnames.append(albumName)
    self.albumimages.append(dict)
        for item in dict{
                   let albumimages =  item["url"] as! String
                albumimge.append(albumimages)

               }
       // print("images:",albumimge)

        
        let count = self.albumnames.count
        if count > 0 {
            self.emptyView.isHidden = true

        }
        }
        print("album name:",self.albumnames)
        self.filteredData = self.albumnames
        self.filteredImagesData = self.albumimages
        //let orderedSet = NSOrderedSet(array: stuff)
        print("images:",albumimge.count)
        let counttt = albumimge.count
        UserDefaults.standard.set(counttt, forKey: "image_Count")

    self.actInd.stopAnimating()
    self.collection.reloadData()
    })

}
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
           let count = albumnames.count
        print("Count:",count)
           UserDefaults.standard.set(count, forKey: "Album_Count")
           return albumnames.count
           
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
           
           //cell.backgroundColor = .red
           cell.layer.cornerRadius = 4
           cell.clipsToBounds = true
           
           collectionImage = UIImageView.init(frame: CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height))
           print(albumimages)
           let imageUrl = albumimages[indexPath.item]
           //collectionImage.image = UIImage.init(named: imageArr[0])
           let albumName = imageUrl[0]["url"]
           let fileUrl = URL(string: albumName as! String)
           print(fileUrl!)
           self.collectionImage.sd_setImage(with: fileUrl!, placeholderImage: UIImage(named: "gallery"))
               
           cell.addSubview(collectionImage)
           let bg = UILabel.init(frame: CGRect(x: 0, y: cell.frame.height-30, width: cell.frame.width, height: 30))
           bg.backgroundColor = .black
           bg.alpha = 0.4
           bg.layer.cornerRadius = 4
                  bg.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner ]
           cell.addSubview(bg)
           albumNameLbl = UILabel.init(frame: CGRect(x: 2, y: cell.frame.height-24, width: cell.frame.width-4, height: 20))
           albumNameLbl.text = albumnames[indexPath.item]
           albumNameLbl.textAlignment = .center
           albumNameLbl.textColor = .white
           albumNameLbl.font = UIFont.boldSystemFont(ofSize: 14)
           cell.addSubview(albumNameLbl)
           deleteBtn = UIButton.init(frame: CGRect(x: cell.frame.width-30, y: 0, width: 30, height: 30))
         deleteBtn.backgroundColor = .black
        deleteBtn.alpha = 0.5
        deleteBtn.layer.cornerRadius = 4
        deleteBtn.clipsToBounds = true
        deleteBtn.setImage(UIImage(named: "more"), for: .normal)
        deleteBtn.addTarget(self, action: #selector(editcellAction), for: .touchUpInside)
        deleteBtn.tag = indexPath.item
         cell.addSubview(deleteBtn)
           
           return cell
       }
    @objc func editcellAction(_ sender: UIButton)  {
         let alert = UIAlertController(title: "", message: "Please Select an Option", preferredStyle: .actionSheet)

           alert.addAction(UIAlertAction(title: "Add photos to Album", style: .default , handler:{ (UIAlertAction)in
               print("User click Approve button")
            self.addAction(self)
           }))

           alert.addAction(UIAlertAction(title: "Delete Album?", style: .default , handler:{ (UIAlertAction)in
               print("Button pressed 👍 ")

            let hitPoint = sender.convert(CGPoint.zero, to: self.collection)
            let hitIndex: IndexPath? = self.collection.indexPathForItem(at: hitPoint)
               let childName = self.albumnames[sender.tag]
               
                         self.collection.performBatchUpdates({
                           self.remove(child: childName)
                           self.collection.deleteItems(at: [hitIndex!])
                           self.albumnames.remove(at: sender.tag)
                           self.albumimages.remove(at: sender.tag)
               }) { (finished) in
                   self.collection.reloadItems(at: self.collection.indexPathsForVisibleItems)
               }
            
           }))

           

           alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler:{ (UIAlertAction)in
               print("User click Dismiss button")
           }))

           self.present(alert, animated: true, completion: {
               print("completion block")
           })
        
    }
    
 func remove(child: String) {
    let refff = self.ref.child("Myfiles/\(user_id!)/\(child)")
        refff.removeValue { error, _ in

            print(error)
        }
    }
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let serachView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "searchBar", for: indexPath) as! SearchBarView
//        serachView.searchBar.delegate = self
//
//        if (searchText != nil && searchText != "") {
//           serachView.searchBar.text! = searchText!
//
//        }
//        return serachView
//    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print(searchText!)
               self.albumnames.removeAll()
               self.albumimages.removeAll()
               print(filteredData!)
               for (index, item) in self.filteredData.enumerated() {
                   print(item.lowercased())
                   print(searchBar.text!.lowercased())
                   if (item.lowercased().contains(searchBar.text!.lowercased())) {
                       self.albumnames.append(item)
                       self.albumimages.append(filteredImagesData[index])
                       
                   }
               }
               if (searchBar.text!.isEmpty) {
                   self.albumnames = self.filteredData
                   self.albumimages = self.filteredImagesData
               }
               self.collection.reloadData()
    }
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        print(searchText)
//        self.albumnames.removeAll()
//        self.albumimages.removeAll()
//        print(filteredData!)
//        for (index, item) in self.filteredData.enumerated() {
//            print(item.lowercased())
//            print(searchBar.text!.lowercased())
//            if (item.lowercased().contains(searchBar.text!.lowercased())) {
//                self.albumnames.append(item)
//                self.albumimages.append(filteredImagesData[index])
//
//            }
//        }
//        if (searchBar.text!.isEmpty) {
//            self.albumnames = self.filteredData
//            self.albumimages = self.filteredImagesData
//        }
//        self.collection.reloadData()
//    }
//    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
//        self.albumnames.removeAll()
//        self.albumimages.removeAll()
//        print(filteredData!)
//        for (index, item) in self.filteredData.enumerated() {
//            print(item.lowercased())
//            print(searchBar.text!.lowercased())
//            if (item.lowercased().contains(searchBar.text!.lowercased())) {
//                self.albumnames.append(item)
//                self.albumimages.append(filteredImagesData[index])
//                
//            }
//        }
//        if (searchBar.text!.isEmpty) {
//            self.albumnames = self.filteredData
//            self.albumimages = self.filteredImagesData
//        }
//        self.collection.reloadData()
//
//        
//    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text! = ""
        if (searchBar.text!.isEmpty) {
            self.albumnames = self.filteredData
            self.albumimages = self.filteredImagesData
        }
        self.collection.reloadData()
    }
       
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
           //let padding: CGFloat =  50
           let collectionViewSize = collectionView.frame.size.width
           let collectionViewSizes = collectionView.frame.size.height
           
        return CGSize(width: collectionViewSize/3-8, height: collectionViewSizes/4.5)
       }
       func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
           let vc = self.storyboard?.instantiateViewController(identifier: "ImageListViewController") as! ImageListViewController
           vc.listImages = albumimages[indexPath.item]
           vc.headerStr = albumnames[indexPath.item]
                  self.navigationController?.pushViewController(vc, animated: true)
       }
       
    
    @IBAction func addAlbumAtion(_ sender: Any) {
        let alertController = UIAlertController(title: "Add New Album Title", message: "", preferredStyle: UIAlertController.Style.alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Add a title"
            textField.borderStyle = UITextField.BorderStyle.none
            textField.autocorrectionType = UITextAutocorrectionType.yes
    }
        
        let saveAction = UIAlertAction(title: "ADD", style: UIAlertAction.Style.default, handler: { alert -> Void in
            let firstTextField = alertController.textFields![0] as UITextField
            
             guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
                       //Show error to user?
                       return
                   }
                   let imagePicker = OpalImagePickerController()
            
            //Present Image Picker
            self.presentOpalImagePickerController(imagePicker, animated: true, select: { (asset) in
                let defaults: UserDefaults? = UserDefaults.standard
                let user_id = defaults!.value(forKey: "user_id") as? String
                var imageDb : [[String:Any]] = []
               print("Selected: \(asset)")
                var sum = 0
                self.actInd.startAnimating()

                for item in asset{
                    sum = sum+1
                    let image = self.getAssetThumbnail(asset: item, size: CGFloat(signOf: 500.0,magnitudeOf: 500.0))
                    print("Finished")

                        if let userID = user_id
                                   {
                                    print(item.value(forKey: "filename")!)
                                    var filepath:URL?
                                    item.requestContentEditingInput(with: PHContentEditingInputRequestOptions()) { (input, _) in
                                        filepath = input?.fullSizeImageURL
                                    }
                                    let imageName = item.value(forKey: "filename")!
                                    //let name = "imageName" + String(sum)
                                    self.uploadMedia(albumName: firstTextField.text!, imageName: imageName as! String, imagee: image, completion: { (url) in
                                        guard let url = url else { return }
                                        if let localpath = filepath?.absoluteString{
                                       let postdata = ["imageName":imageName as! String,"url":url,"localpath":localpath]
                                                                            
                                            imageDb.append(postdata)
                                        }
                                        else{
                                            let postdata = ["imageName":imageName as! String,"url":url,"localpath":""]
                                                                                   
                                            imageDb.append(postdata)
                                        }
                                       self.ref.child("Myfiles/\(user_id!)/\(firstTextField.text!)").setValue(imageDb) {
                                                                                (error:Error?, ref:DatabaseReference) in
                                                                                if let error = error {
                                                                                  print("Data could not be saved: \(error).")
                                                                                } else {
                                                                                  self.actInd.stopAnimating()
                                                                                  self.albumnames.removeAll()
                                                                                  self.albumimages.removeAll()

                                                                                  self.getMyFiles()
                                                                                  print("Data saved successfully!")
                                                                                }
                                                                              }
                                                                               })
                                   }
               
                }

                    self.albumnames.removeAll()
                    //self.getMyFiles()

                    imagePicker.dismiss(animated: true, completion: nil)
                   }, cancel: {
                       //Cancel action?
                    imagePicker.dismiss(animated: true, completion: nil)

                   })
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.destructive, handler: {
            (action : UIAlertAction!) -> Void in })
        
        alertController.addAction(cancelAction)
        alertController.addAction(saveAction)

        self.present(alertController, animated: true, completion: nil)
    }
    @IBAction func addAction(_ sender: Any) {
        let alertController = UIAlertController(title: "Add New Album Title", message: "", preferredStyle: UIAlertController.Style.alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Add a title"
            textField.borderStyle = UITextField.BorderStyle.none
            textField.autocorrectionType = UITextAutocorrectionType.yes
        }
        
        let saveAction = UIAlertAction(title: "ADD", style: UIAlertAction.Style.default, handler: { alert -> Void in
            let firstTextField = alertController.textFields![0] as UITextField
             guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
                       //Show error to user?
                       return
                   }
                   let imagePicker = OpalImagePickerController()

            //Present Image Picker
            self.presentOpalImagePickerController(imagePicker, animated: true, select: { (asset) in
                let defaults: UserDefaults? = UserDefaults.standard
                let user_id = defaults!.value(forKey: "user_id") as? String
                var imageDb : [[String:Any]] = []
               print("Selected: \(asset)")
                var sum = 0
                self.actInd.startAnimating()

                for item in asset{
                    sum = sum+1
                    
                    let image = self.getAssetThumbnail(asset: item, size: CGFloat(signOf: UIScreen.main.bounds.width,magnitudeOf: UIScreen.main.bounds.height))
                    print("Finished")
                        if let userID = user_id
                                   {
                                    print(item.value(forKey: "filename")!)
                                    var filepath:URL?
                                    item.requestContentEditingInput(with: PHContentEditingInputRequestOptions()) { (input, _) in
                                        filepath = input?.fullSizeImageURL
                                    }
                                    let imageName = item.value(forKey: "filename")!
                                    //let name = "imageName" + String(sum)
                                    self.uploadMedia(albumName: firstTextField.text!, imageName: imageName as! String, imagee: image, completion: { (url) in
                                        guard let url = url else { return }
                                        if let localpath = filepath?.absoluteString{
                                       let postdata = ["imageName":imageName as! String,"url":url,"localpath":localpath]
                                                                            
                                            imageDb.append(postdata)
                                        }
                                        else{
                                            let postdata = ["imageName":imageName as! String,"url":url,"localpath":""]
                                                                                   
                                            imageDb.append(postdata)
                                        }
                                   
                                        self.ref.child("Myfiles/\(user_id!)/\(firstTextField.text!)").setValue(imageDb) {
                                          (error:Error?, ref:DatabaseReference) in
                                          if let error = error {
                                            print("Data could not be saved: \(error).")
                                          } else {
                                            self.actInd.stopAnimating()
                                            self.albumnames.removeAll()
                                            self.albumimages.removeAll()

                                            self.getMyFiles()
                                            print("Data saved successfully!")
                                          }
                                        }
                                         })
//                                       let dbRef = self.ref.child("Myfiles/\(user_id!)/\(firstTextField.text!)")
//                                      // let key = dbRef.childByAutoId().key
//                                        dbRef.setValue(imageDb)
                                    

                                   }

                }

                   

                    imagePicker.dismiss(animated: true, completion: nil)
                   }, cancel: {
                       //Cancel action?
                    imagePicker.dismiss(animated: true, completion: nil)

                   })
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.destructive, handler: {
            (action : UIAlertAction!) -> Void in })
        
        alertController.addAction(cancelAction)
        alertController.addAction(saveAction)

        self.present(alertController, animated: true, completion: nil)
    }
    
    func uploadMedia(albumName: String,imageName:String,imagee:UIImage, completion: @escaping (_ url: String?) -> Void) {
        let storageRef = Storage.storage().reference().child("Myfiles/\(user_id!)/\(albumName)/\(imageName)")

        if let uploadData = imagee.jpegData(compressionQuality: 0.1) {

        storageRef.putData(uploadData, metadata: nil, completion: { (metadata, err) in
            if err != nil {
                print("error")
                completion(nil)
            } else {
                storageRef.downloadURL(completion: { (url, error) in

                    print("usrdjkf",url!.absoluteString)
                    let dbRef = self.ref.child("Myfiles/\(self.user_id!)/\(albumName)")
                    //let key = dbRef.childByAutoId().key
                   // dbRef.setValue(url!.absoluteString)
                    completion(url!.absoluteString)
                })                // your uploaded photo url.
            }
            })
        }
    }
    
    @IBAction func settingAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "SettingsViewController") as! SettingsViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func getAssetThumbnail(asset: PHAsset, size: CGFloat) -> UIImage {
        let retinaScale = UIScreen.main.scale
        let retinaSquare = CGSize(width: size * retinaScale, height: size * retinaScale)
        let cropSizeLength = min(asset.pixelWidth, asset.pixelHeight)
        let square = CGRect(x: 0,y: 0, width: CGFloat(cropSizeLength), height: CGFloat(cropSizeLength))
        let cropRect = square.applying(CGAffineTransform(scaleX: 1.0/CGFloat(asset.pixelWidth), y: 1.0/CGFloat(asset.pixelHeight)))
        
        let manager = PHImageManager.default()
        let options = PHImageRequestOptions()
        var thumbnail = UIImage()
        
        options.isSynchronous = true
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact
        //options.normalizedCropRect = cropRect
        
        manager.requestImage(for: asset, targetSize: retinaSquare, contentMode: .aspectFit, options: options, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }
    // MARK: - Utilities

          private func presentAlertViewWithMessage(_ message: String) {
              let alert = UIAlertController(title: "Siri Authorization Status", message: message, preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in
                  self.navigationController?.dismiss(animated: true, completion: nil)
              }))
              navigationController?.present(alert, animated: true, completion: nil)
          }

          /// Updates the `queryOptionsReadableString` with the info from the provided query.
//          func updateQueryUI(with query: PhotoQuery) {
//              let queryOptionsString = query.description
//              //queryOptionsReadableString = queryOptionsString.isEmpty ? ImagesCollectionViewController.noQueryOptionsDescription : queryOptionsString
//          }

}
extension PHAsset {

    var imageee : UIImage {
        var thumbnail = UIImage()
        let imageManager = PHCachingImageManager()
         let quality =  imageManager.allowsCachingHighQualityImages
        imageManager.requestImage(for: self, targetSize: CGSize(width: 300, height: 300), contentMode: .default, options: nil, resultHandler: { image, _ in
            thumbnail = image!
            
        })
        let updatedSize = CGSize(width: 300.0, height: 300.0)
        let resizedImage = self.resizeImage(image: thumbnail, targetSize: updatedSize)
        return resizedImage
    }
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: targetSize.width, height: targetSize.height)
        UIGraphicsBeginImageContextWithOptions(targetSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
}
   







