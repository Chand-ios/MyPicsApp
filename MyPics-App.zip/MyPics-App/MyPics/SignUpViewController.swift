//
//  SignInViewController.swift
//  FutureElite
//
//  Created by eAlpha4Tech on 31/01/20.
//  Copyright © 2020 eAlpha4Tech. All rights reserved.
//

import UIKit
import CRNotifications
import Firebase
import FirebaseAuth


@available(iOS 13.0, *)
class SignUpViewController: UIViewController,UITextFieldDelegate,UIScrollViewDelegate{
    @IBOutlet weak var scrollView: UIScrollView!
       @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var nameTxtFld: UITextField!
    @IBOutlet weak var mobileTxtFld: UITextField!

       @IBOutlet weak var emailTxtFld: UITextField!
       @IBOutlet weak var passwordTxtFld: UITextField!
    @IBOutlet weak var ConfirmpasswordTxtFld: UITextField!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var SignUpBtn: UIButton!
    var ref: DatabaseReference!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()

        scrollView.delegate = self
        emailTxtFld.delegate = self
        passwordTxtFld.delegate = self
        ConfirmpasswordTxtFld.delegate = self

        contentView.layer.shadowPath = UIBezierPath(rect: contentView.bounds).cgPath
        contentView.layer.shadowRadius = 15
        //#colorLiteral(red: 0.8542710543, green: 0.8544148803, blue: 0.8542521, alpha: 1)
         contentView.layer.shadowColor = #colorLiteral(red: 0.6746426225, green: 0.6747580767, blue: 0.6746274829, alpha: 1)
        self.contentView.layer.cornerRadius = 5
        contentView.layer.shadowOffset = .zero
        contentView.layer.shadowOpacity = 0.5
        self.SignUpBtn.layer.cornerRadius = 20
        SignUpBtn.clipsToBounds = true

        //headerView.backgroundColor = .clear
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        self.hidekeyboard()
        
    }
    @IBAction func backAction(_ sender: UIButton) {
     self.navigationController?.popViewController(animated: true)
    }
    @IBAction func signUpAction(_ sender: Any) {
        emailTxtFld.resignFirstResponder()
        passwordTxtFld.resignFirstResponder()
        ConfirmpasswordTxtFld.resignFirstResponder()
    guard nameTxtFld.text != "" else {
       CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Name", dismissDelay: 2)
    return
      }
        
       guard emailTxtFld.text != "" else {
         CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Email", dismissDelay: 2)
      return
        }
        guard mobileTxtFld.text != "" else {
           CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Mobile Number", dismissDelay: 2)
        return
          }
       guard passwordTxtFld.text != "" else {
         CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Password", dismissDelay: 2)
        return
        }
         guard ConfirmpasswordTxtFld.text != "" else {
        CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Confirm Password", dismissDelay: 2)
            return

        }
//        guard emailTxtFld.text!.isValidEmail else
//        {
//            //CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Enter Valid Email", dismissDelay: 2)
//            return
//        }
//        guard passwordTxtFld.count < 6 else{
//            CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "Please enter atleast 6 characters password", dismissDelay: 2)
//
//            return
//        }
        guard ConfirmpasswordTxtFld.text == passwordTxtFld.text else{
                CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "password and  Confirm Password not same", dismissDelay: 2)
            return

        }
        let email = emailTxtFld.text!
        let password = passwordTxtFld.text!
        print(email,password)

        Auth.auth().createUser(withEmail: email, password: password) {(authResult, error) in
                          if let error = error {
                              if let errCode = AuthErrorCode(rawValue: error._code) {
                                  switch errCode {
                                  case .invalidEmail:
                                    print("gvjchbjvk")
                                      CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "invalid mail", dismissDelay: 2)
                                  case .emailAlreadyInUse:
                                    print("gvjchbjvk")

                                    CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "emailAlreadyExistsl", dismissDelay: 2)
                                  default:
                                    print("gvjchbjvk")
                                    CRNotifications.showNotification(type: CRNotifications.error, title: "Error", message: "\(error.localizedDescription)", dismissDelay: 2)
                                  }
                              }
                              return
                          }
                      
            if let user = authResult?.user {
                              //(user.uid)
                              //(user.email as Any)
                            let PostData = ["name": self.nameTxtFld.text!,
                                            "user_email":self.emailTxtFld.text!,"phone_number":self.mobileTxtFld.text!,"user_id": user.uid
                           ]
            let key = user.uid
            let reeff = self.ref.child("Users")
                reeff.child(key).setValue(PostData)
            
        let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
//                        vc.email = emailTxtFld.text
//                        vc.password = passwordTxtFld.text
                        self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
  func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        emailTxtFld.resignFirstResponder()
        passwordTxtFld.resignFirstResponder()
      ConfirmpasswordTxtFld.resignFirstResponder()

        return true
    }
        
    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
        
        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == UIResponder.keyboardWillHideNotification {
            scrollView.contentInset = .zero
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom, right: 0)
        }
        
    }
    
    func hidekeyboard(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer (target: self, action: #selector(Dissmisskeyboard))
        view.addGestureRecognizer(tap)

    }
    
    @objc func Dissmisskeyboard(){
        view.endEditing(true)
    }
    
    
}
extension String {
    var isValidEmail: Bool {
        return NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
   
   
}
