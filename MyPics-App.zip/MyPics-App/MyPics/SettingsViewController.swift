//
//  SettingsViewController.swift
//  MyPics
//
//  Created by eAlphaMac2 on 17/04/20.
//  Copyright © 2020 Terasoftware. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import SDWebImage


@available(iOS 13.0, *)
class SettingsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var photoLbl: UILabel!
    @IBOutlet weak var videoLbl: UILabel!
    @IBOutlet weak var albumLbl: UILabel!
    var nameArr = [String]()
    let imagePicker = UIImagePickerController()
    var base64String = String()

    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var whiteVieew: UIView!
    @IBOutlet weak var tableView: UITableView!

    @IBOutlet weak var backVieew: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let AlbumcountStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "Album_Count") as! CVarArg)
        albumLbl.text = AlbumcountStr as! String
        let imagecountStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "image_Count") as! CVarArg)
        photoLbl.text = imagecountStr as! String
        let version = String.init(format: "Version: %@", Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! CVarArg)
        let nameStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "NAME") as! CVarArg) as! String
        nameLbl.text = nameStr
         let emailStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "EMAIL") as! CVarArg) as! String
         let mobileStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "MOBILE") as! CVarArg) as! String
        let placeholderImage = UIImage(named: "download")
        let imageUrl  = UserDefaults.standard.value(forKey: "Profile_image")
        if let image = imageUrl {
            self.profileImg.sd_setImage(with: URL(string: image as! String), placeholderImage: placeholderImage)

        }
        nameArr = [emailStr,mobileStr,"Rate App","About Us",version,"Logout"]
        tableView.delegate  = self
        tableView.dataSource = self
        whiteVieew.layer.cornerRadius = 12
        whiteVieew.clipsToBounds = true
        
        backVieew.layer.cornerRadius = 30
        backVieew.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner ]
        profileImg.layer.cornerRadius = 40
        profileImg.clipsToBounds = true

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return nameArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                     
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.selectionStyle = .none
        let nameLbl = UILabel.init(frame: CGRect(x: 50, y: 15, width: UIScreen.main.bounds.width-70, height: 30))
        let imgArr = ["email","mobile","rating","about","version","logout"]
        let imgView = UIImageView.init(frame: CGRect(x: 15, y: 18, width: 24, height: 24))
        imgView.image = UIImage.init(named: imgArr[indexPath.row])
        cell.addSubview(imgView)
        
        nameLbl.text =  nameArr[indexPath.row] as? String
        nameLbl.font = UIFont(name: "Open Sans", size: 18)
        //nameLbl.font = UIFont(name: "OpenSans-Semibold", size: 16)
        nameLbl.textColor = .darkGray
        cell.addSubview(nameLbl)
        cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
        cell.backgroundColor = .white//UIColor(red: 238.0/255.0, green: 238.0/255.0, blue: 238.0/255.0, alpha: 1)
                        // back_View.layer.cornerRadius = 4
        cell.clipsToBounds = false
        cell.layer.shadowRadius = 3.0
        cell.layer.shadowOpacity = 0.5
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        cell.layer.shadowColor = UIColor.lightGray.cgColor
        return cell
                              
        }
               
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           tableView.deselectRow(at: indexPath, animated: true)
        
        if indexPath.row == 3
        {
            let vc = self.storyboard?.instantiateViewController(identifier: "AboutViewController") as! AboutViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        if indexPath.row == 5
        {
            let alertController = UIAlertController(title: "You want logout?", message: "", preferredStyle: UIAlertController.Style.alert)
                   
            let saveAction = UIAlertAction(title: "Logout", style: UIAlertAction.Style.default, handler: { alert -> Void in

                let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
                UserDefaults.standard.set(false, forKey: "status")
                self.navigationController?.pushViewController(vc, animated: false)
            })
                let cancelAction = UIAlertAction(title: "No", style: UIAlertAction.Style.destructive, handler: {
                       (action : UIAlertAction!) -> Void in })
                   
                alertController.addAction(cancelAction)
                alertController.addAction(saveAction)

                self.present(alertController, animated: true, completion: nil)
        }
    
     }

    @IBAction func homeAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func nameUpdateAction(_ sender: Any) {
        let alertController = UIAlertController(title: "Update Name!", message: "", preferredStyle: UIAlertController.Style.alert)
        let nameStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "NAME") as! CVarArg) as! String
        alertController.addTextField { (textField : UITextField!) -> Void in
        textField.placeholder = "Add your name"
        textField.text = nameStr
        textField.borderStyle = UITextField.BorderStyle.none
        textField.autocorrectionType = UITextAutocorrectionType.yes
                       
        }
            let saveAction = UIAlertAction(title: "Update", style: UIAlertAction.Style.default, handler: { alert -> Void in
                let firstTextField = alertController.textFields![0] as UITextField
                self.UpdateProfileData(name: firstTextField.text!,ProfileImage: "")


            })
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.destructive, handler: {
                       (action : UIAlertAction!) -> Void in })
                   
                alertController.addAction(cancelAction)
                alertController.addAction(saveAction)

                self.present(alertController, animated: true, completion: nil)
        }
    
                  
    func UpdateProfileData(name:String,ProfileImage:String)  {
        let User_id = UserDefaults.standard.value(forKey:"user_id") as? String

            let Refff = Database.database().reference().child("Users/\(User_id!)")
            //let myRequestRef = Refff.queryOrdered(byChild: "user_id").queryEqual(toValue: User_id!)
            Refff.observeSingleEvent(of: .value, with: { (snapshot) in
                for child in snapshot.children {
                let childSnap = child as! DataSnapshot
                //let senderKey = childSnap.key
                let statusRef = Database.database().reference().child("Users/\(User_id!)")
                    var newValue :[String:Any]!
                    if( name != ""){
                newValue = ["name": name] as [String: Any]
                        UserDefaults.standard.set(name, forKey: "NAME")
                        let nameStr = String.init(format: "%@", UserDefaults.standard.value(forKey: "NAME") as! CVarArg) as! String
                        self.nameLbl.text = nameStr
                        
                    }
                        if( ProfileImage != ""){
                          newValue = ["Profile_image": ProfileImage] as [String: Any]
                        
                        }
                       statusRef.updateChildValues(newValue, withCompletionBlock: { (error, _ ) in

                    
                if error != nil {
                print(error?.localizedDescription ?? "Failed to set status value")
                }
                   
              print("Successfully set status value")
                                      // Update your UI
             DispatchQueue.main.async {
                //self.getProfileData()
            }
                                      
        })
    }
    }) { (error) in
    print("Failed to get snapshot", error)
    }
            
        }
       
    
    @IBAction func profileAction(_ sender: Any) {
       // create the alert
        let alert = UIAlertController(title: nil, message: "Would you want change profile picture?", preferredStyle: UIAlertController.Style.actionSheet)
        
        // add the actions (buttons)
        alert.addAction(UIAlertAction(title: "Camera", style: UIAlertAction.Style.default, handler:{ (action) -> Void in
            self.camera()
            
        }
            
        ))
        alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertAction.Style.default, handler: {
            (action) -> Void in
            self.gallery()
        }))
        
         alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    func camera(){
            let imagepicker = UIImagePickerController()
            imagepicker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
            imagepicker.sourceType = .camera
            imagepicker.allowsEditing = true

            self.present(imagepicker, animated: true, completion: nil)
        }
        
        func gallery(){
            let imagepicker = UIImagePickerController()
            imagepicker.delegate = self
            imagepicker.sourceType = .photoLibrary
            imagepicker.allowsEditing = true

            self.present(imagepicker, animated: true, completion: nil)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true, completion: nil)
        }
    
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
             let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
               // profileImage.contentMode = .scaleAspectFit
                profileImg.image = pickedImage

            let orientationFixedImage = pickedImage!.fixOrientation()

            let imageData = orientationFixedImage.jpegData(compressionQuality: 0.1)

            //let imageData = pickedImage?.pngData()
            base64String = imageData!.base64EncodedString(options: .endLineWithLineFeed)
                //print(base64String)
            if let userID = Auth.auth().currentUser?.uid
                       {
                           let storageRef = Storage.storage().reference().child("Users/\(userID)/profile.jpg")

                        if let uploadData = pickedImage!.jpegData(compressionQuality: 0.1) {

                           storageRef.putData(uploadData, metadata: nil, completion: { (metadata, err) in

                               if err != nil {
                                   //(err!)
                                   return
                               }
                               guard let metadata = metadata else {
                                   // Uh-oh, an error occurred!
                                   return
                                 }
                                 
                                 storageRef.downloadURL { (url, error) in
                                   guard let downloadURL = url else {
                                     return
                                   }
                                   let placeholderImage = UIImage(named: "download")
                                   //self.profileImg = "\(userID)/profile.jpg"
                                   self.UpdateProfileData(name: "", ProfileImage: "profile_image")
                                   self.profileImg.contentMode = .scaleAspectFill
                                   self.profileImg.sd_setImage(with: downloadURL, placeholderImage: placeholderImage)
                                   //(downloadURL)
                                    UserDefaults.standard.set( downloadURL.absoluteString, forKey: "Profile_image")
                                      print(downloadURL)
                                   //(size)
                                    
                            }
                            })
                            }
                               
                                   
                           
                      
                      }
                picker.dismiss(animated: true)

        }

}
extension UIImage {
    func fixOrientation() -> UIImage {
        if self.imageOrientation == UIImage.Orientation.up {
            return self
        }
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        if let normalizedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext() {
            UIGraphicsEndImageContext()
            return normalizedImage
        } else {
            return self
        }
    }
    
    
    
}
