//
//  DragDropCollectionViewCell.swift
//  deleteCell
//
//  Created by eAlphaMac2 on 29/05/20.
//  Copyright © 2020 TeraSoftwareLimited. All rights reserved.
//

import UIKit

class DragDropCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var customLabel: UILabel!

}
