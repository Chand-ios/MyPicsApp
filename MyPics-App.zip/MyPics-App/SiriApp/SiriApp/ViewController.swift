//
//  ViewController.swift
//  SiriApp
//
//  Created by eAlphaMac2 on 13/05/20.
//  Copyright © 2020 TeraSoftwareLimited. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

